#' irace.version
#'
#' A character string containing the version of `irace`.
#' @export
irace.version <- '3.6.3db6f4b'
