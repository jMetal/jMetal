# This file is loaded automatically by testthat.
generate.set.seed <- function()
{
  seed <- sample(2^30, 1)
  cat("Seed: ", seed, "\n")
  set.seed(seed)
}

test_irace_detectCores <- function()
{
  if (!identical(Sys.getenv("NOT_CRAN"), "true")) return(1L)
  x <- Sys.getenv("_R_CHECK_LIMIT_CORES_", "")
  if (nzchar(x) && x == "TRUE") return(2L)
  parallel::detectCores()
}

system_os <- function() tolower(Sys.info()[["sysname"]])
system_os_is <- function(x) system_os() == x

## Functions ##########################################################
f_ackley <- function (x,y, nsize = 0.01) {
  
  # Transformation of parameter values 
  # from [0,1] to [vmin,vmax]
  vmin <- -5
  vmax <- 5
  x <- (x*(vmax-vmin)) + vmin
  y <- (y*(vmax-vmin)) + vmin
  
  a <- -20 * exp (-0.2 * sqrt(0.5 * (x^2 + y^2)))
  b <- exp(0.5 * (cos(2*pi*x) + cos(2*pi*y)))  
  f <- a - b + exp(1) + 20
  # Simulating stochasticity
  noise <- runif(1, min = (1-nsize), max = (1+nsize))
  f <- f*noise
  
  # Transform result from [fmin,fmax]
  # to [0,100]
  fmin <- 0
  fmax <- 15*(1+nsize)
  f <- ((f - fmin) / (fmax-fmin)) * (100-0) + 0
  return(f)
}

f_goldestein_price <- function (x,y, nsize = 0.01) {
  # Trasfomation of parameter values 
  # from [0,1] to [vmin,vmax]
  vmin <- -2
  vmax <- 2
  x <- (x*(vmax-vmin)) + vmin
  y <- (y*(vmax-vmin)) + vmin
  
  a <- 1 + ((x + y + 1)^2) * (19 - 14*x + 3*x^2 - 14*y + 6*x*y + 3*y^2)
  b <- 30 + ((2*x - 3*y)^2) * (18 - 32*x + 12*x^2 + 48*y - 36*x*y + 27*y^2)
  f <- a*b
  # Simulating stochasticity
  noise <- runif(1, min = (1-nsize), max = (1+nsize))
  f <- f*noise

  # Transform result from [fmin,fmax] 
  # to [0,100]
  fmin <- 0
  fmax <- 1000000*(1+nsize)
  f <- ((f - fmin) / (fmax-fmin)) * (100-0) + 0
  return(f)
}

f_matyas <- function (x,y, nsize = 0.01) {
  # Trasfomation of parameter values 
  # from [0,1] to [vmin,vmax]
  vmin <- -10
  vmax <- 10
  x <- (x*(vmax-vmin)) + vmin
  y <- (y*(vmax-vmin)) + vmin
  
  f <- 0.26 * (x^2 + y^2) - (0.48*x*y)
  # Simulating stochasticity
  noise <- runif(1, min = (1-nsize), max = (1+nsize))
  f <- f*noise

  # Transform result from [fmin,fmax] 
  # to [0,100]
  fmin <- 0
  fmax <- 100*(1+nsize)
  f <- ((f - fmin) / (fmax-fmin)) * (100-0) + 0
  return(f)
}

f_himmelblau <- function (x,y, nsize = 0.01) {  
  # Trasfomation of parameter values 
  # from [0,1] to [vmin,vmax]
  vmin <- -5
  vmax <- 5
  x <- (x*(vmax-vmin)) + vmin
  y <- (y*(vmax-vmin)) + vmin
  
  
  f <- (x^2 + y - 11)^2 + (x + y^2 - 7)^2
  # Simulating stochasticity
  noise <- runif(1, min = (1-nsize), max = (1+nsize))
  f <- f*noise
  
  # Transform result from [fmin,fmax] 
  # to [0,100]
  fmin <- 0
  fmax <- 2000*(1+nsize)
  f <- ((f - fmin) / (fmax-fmin)) * (100-0) + 0
  return(f)
}
