#' irace.version
#'
#' A character string containing the version of \pkg{irace}.
#'
#' @export
irace.version <- '3.1.2112M'
