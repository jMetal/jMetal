library(testthat)
library(irace)
test_check("irace")
