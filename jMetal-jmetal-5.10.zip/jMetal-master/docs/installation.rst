Installation
============
jMetal is a Maven project hosted in GitHub, so there are two ways of getting the software: adding it as a dependence in your own Maven project, or getting the source code from https://github.com/jMetal/jMetal.

The software requirements to use jMetal are:

* Java 11 JDK 
* Maven
* Optional: R, Latex.

To work with the last development version, just clone the repository in https://github.com/jMetal/jMetal.
