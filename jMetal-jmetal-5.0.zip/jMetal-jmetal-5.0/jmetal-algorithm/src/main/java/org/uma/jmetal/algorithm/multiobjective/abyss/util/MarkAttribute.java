package org.uma.jmetal.algorithm.multiobjective.abyss.util;

import org.uma.jmetal.solution.Solution;
import org.uma.jmetal.util.solutionattribute.impl.GenericSolutionAttribute;

/**
 * Created by cbarba on 24/3/15.
 */
public class MarkAttribute extends GenericSolutionAttribute<Solution<?>,Boolean> {
}
